/*liftWA.jsx
	ワークエリアを抽出（すっこ抜くとか引っこ抜くとか削除の方が適切）
*/
nas=app.nas;nas.axeCMC.execWithReference("timelineExtractWorkArea");