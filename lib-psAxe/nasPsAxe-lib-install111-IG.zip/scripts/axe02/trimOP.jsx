/*trinOP.jsx
再生ヘッドを終了点でトリミング
*/
nas=app.nas;nas.axeCMC.execWithReference("timelineTrimLayerEnd");