/*trinIP.jsx
	OUT点に移動
*/
nas=app.nas;nas.axeCMC.execWithReference("timelineMoveLayerEndPoint");