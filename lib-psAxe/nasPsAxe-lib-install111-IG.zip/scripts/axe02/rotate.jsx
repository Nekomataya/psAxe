alert(app.activeDocument.activeLayer.name);
app.activeDocument.activeLayer.rotate(45);
alert(app.activeDocument.activeLayer.name);
