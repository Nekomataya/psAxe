/*swcFAV.jsx
showAllLayers
*/
nas=app.nas;nas.axeCMC.execWithReference("timelineShowAllLayers");