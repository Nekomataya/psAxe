/*trinIP.jsx
再生ヘッドを開始点でトリミング
*/
nas=app.nas;nas.axeCMC.execWithReference("timelineTrimLayerStart");