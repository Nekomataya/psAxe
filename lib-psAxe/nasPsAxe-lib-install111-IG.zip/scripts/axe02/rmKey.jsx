/*
ヘッド位置のアクティブレイヤの不透明度キーフレームを削除
*/
nas=app.nas;nas.axeVTC.switchKeyFrame ("Dlt ");