/*sliceTL.jsx
	レイヤ分割
*/
nas=app.nas;nas.axeCMC.execWithReference("timelineSplitLayer");