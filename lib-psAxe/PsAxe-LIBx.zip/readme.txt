﻿psAxe ver1.1.1 ライブラリ　インストール手順
2015.05.27 Nekomataya/kiyo
--------------------------

psAxe単体ライブラリをダウンロードいただきありがとうございます


2015.05.27

ライブラリ内のファイルに問題があることがわかりました
複数バージョンのPhotoshopをインストールした状態で、一定数のスクリプトが特定のバージョン以外では動作しなくなるという問題です
このアーカイブのライブラリは、この問題に対処済みです

psAxe v1.1テスト版をご利用の方でこの問題に対応するためには、この単体ライブラリをインストールしてください

インストールは nasPsAxeInstall.jsx　を　Photoshopスクリプトとして実行してください

Photoshopを開き、メニューを「ファイル」＞「スクリプト」＞「参照..」とたどり" nasPsAxeInstall.jsx"を開くか、または
 "nasPsAxeInstall.jsx"をAdobe ExtendScript Toolkit(ESTK)から開き、ホストアプリケーションに"Photoshop"を選択して実行させてください




2015/05/27 ねこまたや
WEBSITE:	thhp://www.nekomataya.info/
連絡先：	support@nekomataya.info
