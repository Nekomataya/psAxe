/*addFav.jsx
	お気に入りのレイヤに設定
*/
nas=app.nas;nas.axeCMC.execWithReference("timelineShowSetFavoriteLayers");