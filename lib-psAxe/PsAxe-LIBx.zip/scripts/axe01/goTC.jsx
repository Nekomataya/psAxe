/*goTC.jsx
 TC指定で再生ヘッドを移動
 暫定版　nasFCTに変更予定
*/
nas=app.nas;nas.axeCMC.execWithReference("timelineGoToTime");