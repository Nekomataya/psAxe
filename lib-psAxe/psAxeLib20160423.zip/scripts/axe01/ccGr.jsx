/*ccGr.jsx
ラベルカラー設定
*/
app.nas.axeCMC.applyLabelColored("Grn "); 
