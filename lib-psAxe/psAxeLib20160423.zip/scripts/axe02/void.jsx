	nas=app.nas;
	nas.uiMsg["void"]={
	en:"This feature is currently not implemented. Please wait",
	ja:"この機能は、現在未実装です。しばらくお待ちください"
	};
	alert(nas.localize(nas.uiMsg["void"]));
