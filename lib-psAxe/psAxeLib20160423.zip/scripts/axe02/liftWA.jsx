/*liftWA.jsx
	ワークエリアをリフト
*/
nas=app.nas;nas.axeCMC.execWithReference("timelineLiftWorkArea");