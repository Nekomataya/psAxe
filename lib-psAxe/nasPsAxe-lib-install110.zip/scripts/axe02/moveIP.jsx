/*trinIP.jsx
	IN点に移動
*/
nas=app.nas;nas.axeCMC.execWithReference("timelineMoveLayerInPoint");