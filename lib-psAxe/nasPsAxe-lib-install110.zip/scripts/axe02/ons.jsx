/*
	オニオンスキン表示
*/
nas=app.nas;nas.axeCMC.execWithReference("timelineEnableOnionSkins");