/*
ヘッド位置のアクティブレイヤに不透明度キーフレームを作成
キー補間法は停止で作成する
*/
nas=app.nas;
var desc=nas.axeVTC.switchKeyFrame ("Mk  ");
nas.axeVTC.switchKeyInterp ("hold");