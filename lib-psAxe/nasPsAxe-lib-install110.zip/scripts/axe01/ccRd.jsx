/*ccRd.jsx
ラベルカラー設定
*/
app.nas.axeCMC.applyLabelColored("Rd  "); 
