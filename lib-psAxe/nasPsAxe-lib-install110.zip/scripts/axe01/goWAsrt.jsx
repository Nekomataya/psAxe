/*goWAsrt.jsx
 ワークエリア先頭へ再生ヘッドを移動
*/
nas=app.nas;nas.axeCMC.execWithReference("timelineGoToWorkAreaStart");