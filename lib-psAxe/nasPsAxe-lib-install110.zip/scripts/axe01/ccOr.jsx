/*ccOr.jsx
ラベルカラー設定
*/
app.nas.axeCMC.applyLabelColored("Orng"); 
