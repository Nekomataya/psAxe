function setup()
{
	return 0;
}
