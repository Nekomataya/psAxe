/*ccX.jsx
ラベルカラー設定
*/
app.nas.axeCMC.applyLabelColored("None"); 
