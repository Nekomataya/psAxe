/*
	オニオンスキン設定
*/
nas=app.nas;nas.axeCMC.execWithReference("timelineOnionSkinSettings");