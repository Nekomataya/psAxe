/*goWAend.jsx
 ワークエリア終端へ再生ヘッドを移動
*/
nas=app.nas;nas.axeCMC.execWithReference("timelineGoToWorkAreaEnd");